/**
 * env.js — gerado automaticamente, NÃO edite manualmente
 * Este arquivo é criado pelo servidor/build a partir do .env
 * Está listado no .gitignore e NUNCA deve ser commitado
 *
 * Para gerar localmente, execute:
 *   node generate-env.js
 */
window.ENV = {
  SUPABASE_URL:      "https://srgkbigqtctyzqyvyiis.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNyZ2tiaWdxdGN0eXpxeXZ5aWlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk3NDAxNTQsImV4cCI6MjA5NTMxNjE1NH0.jFMb8st5JI0VIZylaZ2jw5i_ld5L4ittGakFVtbBcKU",
  ADMIN_USER:        "admin",
  ADMIN_PASS:        "loja@ivonne",
  COUPON_CODE:       "ivonnestorecompra1",
  COUPON_VALIDITY:   "31/07/2026",
};
